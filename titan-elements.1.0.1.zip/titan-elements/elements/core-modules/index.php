<?php
/*  Silence is pretty much golden */
?>